//
//  InputVC.swift
//  CTIS480_Fall2122_HW2
//
//  
//

import UIKit

protocol InputControllerDelegate {
    func obtainData(controller: InputVC, data: (p1: Double, p2: Double))
}

class InputVC: UIViewController {
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var bottomLabel: UILabel!
    
    var selectedShape = 0
    var delegate: InputControllerDelegate?
    
    // 0 --> Triangle, 1 --> Circle,  2 --> Rectangle
    func setInputs() {
        if selectedShape == 0 {             // Trianngle
            bottomLabel.isHidden = false
            bottomTextField.isHidden = false
            
            topLabel.text = "Base:"
            bottomLabel.text = "Height:"
            
            topTextField.placeholder = "enter base value"
            bottomTextField.placeholder = "enter height value"
        }
        else if selectedShape == 1 {        // Circle
            
            bottomLabel.isHidden = true
            bottomTextField.isHidden = true
            
            topLabel.text = "Radius:"
            topTextField.placeholder = "enter radius value"
            
        }
        else {                              // Rectangle
            bottomLabel.isHidden = false
            bottomTextField.isHidden = false
            
            topLabel.text = "Length:"
            bottomLabel.text = "Width:"
            
            topTextField.placeholder = "enter length value"
            bottomTextField.placeholder = "enter width value"
        }
    }
    
    func getData() -> (Double, Double) {
        var input1 = 1.0
        var input2 = 1.0
        
        if selectedShape == 1 {
            input1 = Double(topTextField.text!)!
            input2 = 1.0
        }
        else {
            input1 = Double(topTextField.text!)!
            input2 = Double(bottomTextField.text!)!
        }
        
        return (input1, input2)
    }
    
    @IBAction func onDone(_ sender: UIBarButtonItem) {
        if selectedShape == 1 {
            if topTextField.text!.isEmpty {
                displayAlert(header: "Error", msg: "Radius cannot be empty")
            }
            else {
                delegate?.obtainData(controller: self, data: getData())
            }
        }
        else {
            if(topTextField.text!.isEmpty || bottomTextField.text!.isEmpty) {
                displayAlert(header: "Error", msg: "Data cannot be empty")
            }
            else {
                delegate?.obtainData(controller: self, data: getData())
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func displayAlert (header: String, msg: String) {
        // Creating an Alert and display the result
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: .alert)
        // Event Handler for the button
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        // Displaying the Alert
        self.present(mAlert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //print(selectedShape)
        setInputs()
    }

}
