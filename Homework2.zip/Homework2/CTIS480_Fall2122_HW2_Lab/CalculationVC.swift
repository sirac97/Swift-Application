//
//  CalculationVC.swift
//  CTIS480_Fall2122_HW2
//
//  
//

import UIKit


class CalculationVC: UIViewController, InputControllerDelegate {
    
    @IBOutlet weak var mImageView: UIImageView!
    
    var shapeArray = ["Triangle", "Circle", "Rectangle"]
    
    // 0 --> Triangle, 1 --> Circle,  2 --> Rectabgle
    var selectedShape = 0
    
    
    func obtainData(controller: InputVC, data: (p1: Double, p2: Double)) {
        controller.navigationController?.popViewController(animated: true)
        
        if selectedShape == 0 {
            let perimeter = trianglePerimeter(base: data.p1, height: data.p2)
            let area = triangleArea(base: data.p1, height: data.p2)
            let output = String(format: "Triangle Perimeter = %0.2f\n Triangle Area = %0.2f", perimeter, area)
            displayAlert(header: "Result", msg: output)
        }
        else if selectedShape == 1 {
            let perimeter = circlePerimeter(radius: data.p1)
            let area = circleArea(radius: data.p1)
            let output = String(format: "Circle Perimeter = %0.2f\n Circle Area = %0.2f", perimeter, area)
            displayAlert(header: "Result", msg: output)
        }
        else {
            let perimeter = rectanglePerimeter(length: data.p1, width: data.p2)
            let area = rectangleArea(length: data.p1, width: data.p2)
            let output = String(format: "Rectangle Perimeter = %0.2f\n Rectangle Area = %0.2f", perimeter, area)
            displayAlert(header: "Result", msg: output)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func circlePerimeter(radius: Double) -> Double {
        return ( 2.0 * .pi * radius)
    }
    
    func circleArea(radius: Double) -> Double {
        return ( .pi * pow(radius, 2.0) )
    }
    
    func trianglePerimeter(base: Double, height: Double) -> Double {
        return ( base + height + sqrt( pow(base, 2.0) + pow(height, 2.0) ) )
    }
    
    func triangleArea(base: Double, height: Double) -> Double {
        return ( 1.0/2.0 * base * height )
    }
    
    func rectanglePerimeter(length: Double, width: Double) -> Double {
        return ( 2 * length  + 2 * width )
    }
    
    func rectangleArea(length: Double, width: Double) -> Double {
        return ( length * width )
    }
    
    func displayAlert(header: String, msg: String) {
        // Creating an Alert and display the result
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: UIAlertController.Style.alert)
        // Event Handler for the button
        mAlert.addAction(UIAlertAction(title: "Close", style: UIAlertAction.Style.default, handler: nil))
        // Displaying the Alert
        self.present(mAlert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "calculation" {
            if let vc = segue.destination as? InputVC {
                //print("Right place")
                //print(selectedShape)
                vc.navigationItem.title = shapeArray[selectedShape]
                vc.delegate = self
                vc.selectedShape = selectedShape
                vc.delegate = self
            }
        }
    }
    
    override func viewDidLoad() {
           super.viewDidLoad()
           
       }
    
}

extension CalculationVC: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return shapeArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return shapeArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        selectedShape = row
        mImageView.image = UIImage(named: shapeArray[row].lowercased())
    }
    
}
