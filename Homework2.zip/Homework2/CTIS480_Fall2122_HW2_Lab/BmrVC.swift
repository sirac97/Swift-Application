//
//  FitnessVC.swift
//  CTIS480_Fall2122_HW2
//
//  
//

import UIKit

class BmrVC: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    @IBOutlet weak var height: UITextField!
    @IBOutlet weak var weight: UITextField!
    
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    var age = 10
    var gender = 0          // male (on) = 0, female (off) = 1
    var activityMultiplier = 1.0
    var pickerArray : NSMutableArray = []
    
    @IBAction func ageSlider(sender: UISlider) {
        age = Int(sender.value)
        ageLabel.text = ("Age (\(age) years):")
        
        self.height.resignFirstResponder()
        self.weight.resignFirstResponder()
    }
    
    @IBAction func genderSwitch(sender: UISwitch) {
        self.height.resignFirstResponder()
        self.weight.resignFirstResponder()
        
        if sender.isOn {
            gender = 0      // male
            genderLabel.text = ("Gender (male):")
        }
        else {
            gender = 1      // female
            genderLabel.text = ("Gender (female):")
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func Calculate(sender: UIButton) {
        self.height.resignFirstResponder()
        self.weight.resignFirstResponder()
        
        let weightKg = Double(weight.text!) ?? 0.0
        let heightCm = Double(height.text!) ?? 0.0
        var bmr = 0.0
        
        if (height.text!.isEmpty || weight.text!.isEmpty) {
            bmr = 0.0
        }
        else {
            if gender == 0 {    // male
                bmr = 10.0 * weightKg + 6.25 * heightCm - 5.0 * Double(age) + 5.0
            }
            else {      // female
                bmr = 10.0 * weightKg + 6.25 * heightCm - 5.0 * Double(age) - 161.0
            }
            
            // Scale bmr
            bmr *= activityMultiplier
        }
        
        
        if gender == 0 {
            let mMessage = String(format: "BMR(male, \(age) Years) = %0.2f", bmr)
            
            let bmrAlert = UIAlertController(title: "BMR Result", message: mMessage, preferredStyle: UIAlertController.Style.alert)
            bmrAlert.addAction(UIAlertAction(title: "Close", style: UIAlertAction.Style.default, handler: nil))
            self.present(bmrAlert, animated: true, completion: nil)
        }
        else {
            let mMessage = String(format: "BMR(female, \(age) Years) = %0.2f", bmr)
            
            let bmrAlert = UIAlertController(title: "BMR Result", message: mMessage, preferredStyle: UIAlertController.Style.alert)
            bmrAlert.addAction(UIAlertAction(title: "Close", style: UIAlertAction.Style.default, handler: nil))
            self.present(bmrAlert, animated: true, completion: nil)
        }
        
    }
    
    // The number spinning wheels (i.e., columns)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of items/rows in the componets
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerArray.count
    }
    
    // Called automatically multiple times. To attach the data
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return (pickerArray[row] as! String)
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.height.resignFirstResponder()
        self.weight.resignFirstResponder()
        
        switch row {
        case 0:
            //print(pickerArray[row])
            activityMultiplier = 1.0
        case 1:
            //print(pickerArray[row])
            activityMultiplier = 1.375
        case 2:
            //print(pickerArray[row])
            activityMultiplier = 1.55
        case 3:
            //print(pickerArray[row])
            activityMultiplier = 1.725
        default:
            print(pickerArray[row])
            activityMultiplier = 1.9
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let bundle = Bundle.main
        
        if let url = bundle.url(forResource: "types", withExtension: "plist") {
            pickerArray = NSMutableArray(contentsOf: url)!
        }
        
        //print(pickerArray)
        
        // To add Keyboard type via code
        height.keyboardType = UIKeyboardType.decimalPad
        weight.keyboardType = UIKeyboardType.decimalPad
    }
}
