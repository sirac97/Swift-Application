//
//  StartVC.swift
//  CTIS480_Fall2122_HW2
//
// 
//
import UIKit
// All StartVC images are created using https://cooltext.com

enum Controller: Int {
    case one = 1, two, three, four
}

class StartVC: UIViewController {
    // Using enum to determine the selected VC
    // 1 -> Calculation, 2 -> BMR, 3 -> Player, 4 -> Chart
    var controller = Controller.one
    
    @IBOutlet weak var mImageView: UIImageView!
    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    
    @IBAction func unwindToStart(_ segue: UIStoryboardSegue) {
        
    }
    
    @IBAction func onSegmentChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            mImageView.image = UIImage(named: "calculation")
            mLabel.text = "Calculation Controller"
            controller = Controller.one
        case 1:
            mImageView.image = UIImage(named: "bmr")
            mLabel.text = "BMR Controller"
            controller = Controller.two
        case 2:
            mImageView.image = UIImage(named: "players")
            mLabel.text = "Player Controller"
            controller = Controller.three
        case 3:
            mImageView.image = UIImage(named: "chart")
            mLabel.text = "Chart Controller"
            controller = Controller.four
        default:
            break
        }
    }
    
    // MARK: Single tapping an image will change the UISegmentedControl index
    @IBAction func onSingleTapGesture(_ sender: UITapGestureRecognizer) {
        switch (controller) {
        case .one:
            mSegmentedControl.selectedSegmentIndex = 1
            mImageView.image = UIImage(named: "bmr")
            mLabel.text = "BMR Controller"
            controller = .two
        case .two:
            mSegmentedControl.selectedSegmentIndex = 2
            mImageView.image = UIImage(named: "players")
            mLabel.text = "Player Controller"
            controller = .three
        case .three:
            mSegmentedControl.selectedSegmentIndex = 3
            mImageView.image = UIImage(named: "chart")
            mLabel.text = "Chart Controller"
            controller = .four
        case .four:
            mSegmentedControl.selectedSegmentIndex = 0
            mImageView.image = UIImage(named: "calculation")
            mLabel.text = "Calculation Controller"
            controller = .one
        }
    }
    
    // MARK: Long press to create a segue
    @IBAction func onLongPressGesture(_ sender: UILongPressGestureRecognizer) {
        switch (controller) {
        case .one:
            self.performSegue(withIdentifier: "calculation", sender: self)
        case .two:
            self.performSegue(withIdentifier: "bmr", sender: self)
        case .three:
            self.performSegue(withIdentifier: "player", sender: self)
        case .four:
            self.performSegue(withIdentifier: "chart", sender: self)
        }
    }
    
    
    // MARK: To pass parameter(s) to the other Scenes
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "chart" {
          // not necessary
        }
        else {
            // not necessary
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //definesPresentationContext = true
    }
    
}
