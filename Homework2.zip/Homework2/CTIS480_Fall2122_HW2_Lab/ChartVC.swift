//
//  ChartVC.swift
//  CTIS480_Fall2122_HW2
//
//  
//

import UIKit
import Charts

class ChartVC: UIViewController, ChartViewDelegate {
    @IBOutlet weak var mBarChartView: BarChartView!
    
    let country = ["Turkey", "USA", "Brazil", "India"]
    let cases = [25.0, 46.6, 21.9, 34.4]
    let deaths = [5.06, 7.55, 6.10, 4.61]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        mBarChartView.delegate = self
        mBarChartView.noDataText = "You need to provide data for the chart."
        mBarChartView.chartDescription?.text = "Cases and Deaths"
        
        
        //legend
        let legend = mBarChartView.legend
        legend.font = UIFont(name: "Verdana", size: 16.0)!
        legend.enabled = true
        legend.horizontalAlignment = .right
        legend.verticalAlignment = .top
        legend.orientation = .vertical
        legend.drawInside = true
        legend.yOffset = 10.0;
        legend.xOffset = 10.0;
        legend.yEntrySpace = 0.0;
        
   
        let xaxis = mBarChartView.xAxis
        
        //xaxis.valueFormatter = axisFormatDelegate
        xaxis.drawGridLinesEnabled = true
        xaxis.labelPosition = .bottom
        xaxis.labelFont = UIFont(name: "Verdana", size: 14.0)!
        xaxis.centerAxisLabelsEnabled = true
        xaxis.valueFormatter = IndexAxisValueFormatter(values: self.country)
        xaxis.granularity = 1
        
        
        let leftAxisFormatter = NumberFormatter()
        leftAxisFormatter.maximumFractionDigits = 1
        
        let yaxis = mBarChartView.leftAxis
        yaxis.labelFont = UIFont(name: "Verdana", size: 14.0)!
        yaxis.spaceTop = 0.35
        yaxis.axisMinimum = 0
        yaxis.drawGridLinesEnabled = false
        
        mBarChartView.rightAxis.enabled = false
        //axisFormatDelegate = self
        
        setChart()
    }
    
    func setChart() {
        mBarChartView.noDataText = "You need to provide data for the chart."
        var dataEntries: [BarChartDataEntry] = []
        var dataEntries1: [BarChartDataEntry] = []
        
        for i in 0..<self.country.count {
            
            let dataEntry = BarChartDataEntry(x: Double(i) , y: self.cases[i])
            dataEntries.append(dataEntry)
            
            let dataEntry1 = BarChartDataEntry(x: Double(i) , y: self.deaths[i])
            dataEntries1.append(dataEntry1)
            
            //stack barchart
            //let dataEntry = BarChartDataEntry(x: Double(i), yValues:  [self.unitsSold[i],self.unitsBought[i]], label: "groupChart")
        }
        
        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "Cases")
        let chartDataSet1 = BarChartDataSet(entries: dataEntries1, label: "Deaths")
        
        let dataSets: [BarChartDataSet] = [chartDataSet,chartDataSet1]
        chartDataSet.colors = [UIColor(red: 200/255, green: 120/255, blue: 50/255, alpha: 1)]
        chartDataSet.valueFont = UIFont(name: "Verdana", size: 12.0)!
        chartDataSet1.valueFont = UIFont(name: "Verdana", size: 12.0)!
        //chartDataSet.colors = ChartColorTemplates.colorful()
        //let chartData = BarChartData(dataSet: chartDataSet)
        
        let chartData = BarChartData(dataSets: dataSets)
        
        
        let groupSpace = 0.3
        let barSpace = 0.05
        let barWidth = 0.3
        // (0.3 + 0.05) * 2 + 0.3 = 1.00 -> interval per "group"
        
        let groupCount = self.country.count
        let startYear = 0
        
        
        chartData.barWidth = barWidth;
        mBarChartView.xAxis.axisMinimum = Double(startYear)
        let gg = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace)
        print("Groupspace: \(gg)")
        mBarChartView.xAxis.axisMaximum = Double(startYear) + gg * Double(groupCount)
        
        chartData.groupBars(fromX: Double(startYear), groupSpace: groupSpace, barSpace: barSpace)
        //chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace)
        mBarChartView.notifyDataSetChanged()
        
        mBarChartView.data = chartData
        
        //background color
        mBarChartView.backgroundColor = UIColor(red: 225/255, green: 225/255, blue: 225/255, alpha: 1.0)
        
        //chart animation
        mBarChartView.animate(xAxisDuration: 1.5, yAxisDuration: 1.5, easingOption: .linear)
    }
}
