//
//  PlayersVC.swift
//  CTIS480_Spr2021_HW2
//
//  
//

import UIKit

class PlayerVC: UIViewController {
    
    @IBOutlet weak var mPickerView: UIPickerView!
    @IBOutlet weak var mTableView: UITableView!
    
    //var keysArray = Array(arrayLiteral: String())
    //var keysArray = [String]()
    
    // PickerView array
    var teamPlayers = [String]()
    // TableView array
    var allPlayers = [(String, String)]()
    // Flag array
    var isTableViewFilled = [Int](repeating: 0, count: 3)
    
    @IBAction func onBesiktasTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
        teamPlayers.removeAll()
        populateData(team: "besiktas")
        mPickerView.reloadAllComponents()
        
        if isTableViewFilled[0] == 0 {
            isTableViewFilled[0] = 1
            
            for x in 0..<teamPlayers.count {
                allPlayers.append((teamPlayers[x],"besiktas"))
            }
            
            mTableView.reloadData()
        }
        
    }
    
    
    @IBAction func onFenerbahceTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
        teamPlayers.removeAll()
        populateData(team: "fenerbahce")
        mPickerView.reloadAllComponents()
        
        if isTableViewFilled[1] == 0 {
            isTableViewFilled[1] = 1
            
            for x in 0..<teamPlayers.count {
                allPlayers.append((teamPlayers[x],"fenerbahce"))
            }
            
            mTableView.reloadData()
        }
    }
    
    @IBAction func onGalatasarayTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
        teamPlayers.removeAll()
        populateData(team: "galatasaray")
        mPickerView.reloadAllComponents()
        
        if isTableViewFilled[2] == 0 {
            isTableViewFilled[2] = 1
            
            for x in 0..<teamPlayers.count {
                allPlayers.append((teamPlayers[x],"galatasaray"))
            }
            
            mTableView.reloadData()
        }
        
    }
    
    func populateData(team: String) {
        if let path = Bundle.main.path(forResource: "players", ofType: "plist") {
            if let dictArray = NSArray(contentsOfFile: path) {
                for item in dictArray {
                    if let dict = item as? NSDictionary {
                        if (dict.allKeys[0] as! String) == team {
                            teamPlayers.append(dict.allValues[0] as! String)
                        }
                    }
                }
            }
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
}

extension PlayerVC: UIPickerViewDataSource, UIPickerViewDelegate {
    // The number spinning wheels (i.e., columns)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of items/rows in the componets
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return teamPlayers.count
    }
    
    // Called automatically multiple times. To attach the data
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return teamPlayers[row]
    }
    
    // Defining the height of the row in UIPickerView
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 50.0
    }
    
}

extension PlayerVC: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPlayers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        let (player, team) = allPlayers[indexPath.row]
        
        // Due to tuple (String, String) no need to write if else
        /*if team == "besiktas" {
            cell.imageView?.image = UIImage(named: "besiktas")
        }
        else if team == "fenerbahce" {
            cell.imageView?.image = UIImage(named: "fenerbahce")
        }
        else if team == "galatasaray" {
            cell.imageView?.image = UIImage(named: "galatasaray")
        }*/
        
        cell.imageView?.image = UIImage(named: team)
        cell.textLabel?.text = player
        
        return cell
    }
}
